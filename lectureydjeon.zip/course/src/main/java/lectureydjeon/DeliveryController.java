package lectureydjeon;

import org.springframework.web.bind.annotation.RestController;

 @RestController
 public class DeliveryController {
 }
