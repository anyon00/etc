package ctcdabl;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

// @RepositoryRestResource(collectionResourceRel="dabls", path="dabls")
public interface DablRepository extends PagingAndSortingRepository<Dabl, Long>{

    List<Dabl> findBydablid(Long ctcId);


}
