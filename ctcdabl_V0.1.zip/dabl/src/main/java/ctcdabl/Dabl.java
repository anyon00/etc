package ctcdabl;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;

@Entity
@Table(name="Dabl_table")
public class Dabl {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Long dablid;
    private String dablmemo;
    private String status;

    @PostPersist
    public void onPostPersist(){
        DablRegistered dablRegistered = new DablRegistered();
        BeanUtils.copyProperties(this, dablRegistered);
        dablRegistered.publishAfterCommit();
    }

    @PostUpdate
    public void onPostUpdate(){
        Dablmodified dablmodified = new Dablmodified();
        BeanUtils.copyProperties(this, dablmodified);
        dablmodified.publishAfterCommit();


    }

    @PreRemove
    public void onPreRemove(){
        Dablcancel dablcancel = new Dablcancel();
        BeanUtils.copyProperties(this, dablcancel);
        dablcancel.publishAfterCommit();


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getDablid() {
        return dablid;
    }

    public void setDablid(Long dablid) {
        this.dablid = dablid;
    }
    public String getDablmemo() {
        return dablmemo;
    }

    public void setDablmemo(String dablmemo) {
        this.dablmemo = dablmemo;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }




}
