package ctcdabl;

public class Dablcancel extends AbstractEvent {

    private Long id;
    private Long dableid;
    private String dablmemo;

    public Dablcancel(){
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getDableid() {
        return dableid;
    }

    public void setDableid(Long dableid) {
        this.dableid = dableid;
    }
    public String getDablmemo() {
        return dablmemo;
    }

    public void setDablmemo(String dablmemo) {
        this.dablmemo = dablmemo;
    }
}
