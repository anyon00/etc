package ctcdabl;

public class Dablmodified extends AbstractEvent {

    private Long id;
    private Long dableid;
    private String dablememo;

    public Dablmodified(){
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getDableid() {
        return dableid;
    }

    public void setDableid(Long dableid) {
        this.dableid = dableid;
    }
    public String getDablememo() {
        return dablememo;
    }

    public void setDablememo(String dablememo) {
        this.dablememo = dablememo;
    }
}
