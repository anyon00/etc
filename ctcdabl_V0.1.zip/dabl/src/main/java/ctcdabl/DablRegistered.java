package ctcdabl;

public class DablRegistered extends AbstractEvent {

    private Long id;
    private Long dablid;
    private String dablreason;

    public DablRegistered(){
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getDablid() {
        return dablid;
    }

    public void setDablid(Long dablid) {
        this.dablid = dablid;
    }
    public String getDablreason() {
        return dablreason;
    }

    public void setDablreason(String dablreason) {
        this.dablreason = dablreason;
    }
}
