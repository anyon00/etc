package ctcdabl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Optional;

 @RestController
 public class DablController {
        @Autowired
        DablRepository dablRepository;

        @PostMapping(value = "/succeedDabl")
        public boolean succeedDabl(@RequestBody Map<String, String> param) {
    
            Dabl dabl = new Dabl();
            boolean result = false;
    
            dabl.setDablid(Long.parseLong(param.get("ctcId")));
            dabl.setDablmemo(param.get("memo"));
            dabl.setStatus("DABL_CREATE");
    
            try {
                dabl = dablRepository.save(dabl);
                result = true;
            } catch (Exception e) {
                e.printStackTrace();
            }
    
            return result;
        }

    @PostMapping(value = "/dabl")
    public Dabl registerDabl(@RequestBody Map<String, String> param) {

        Dabl dabl = new Dabl();

        dabl.setDablid(Long.parseLong(param.get("ctcId")));
        dabl.setDablmemo(param.get("memo"));
        dabl.setStatus("DABL_CREATE");

        dabl = dablRepository.save(dabl);

        return dabl;
    }

    @PatchMapping(value = "/dabl/{id}")
    public Dabl modifyDabl(@RequestBody Map<String, String> param, @PathVariable String id) {

        Optional<Dabl> opt = dablRepository.findById(Long.parseLong(id));
        Dabl dabl = null;

        if (opt.isPresent()) {
                dabl = opt.get();

            if (param.get("ctcId") != null)
                dabl.setDablid(Long.parseLong(param.get("ctcId")));
            if (param.get("memo") != null)
                dabl.setDablmemo(param.get("memo"));
            if (param.get("status") != null)
                dabl.setStatus(param.get("status"));

            dabl = dablRepository.save(dabl);
        }

        return dabl;
    }

    @PutMapping(value = "/dabl/{id}")
    public Dabl modifydablPut(@RequestBody Map<String, String> param, @PathVariable String id) {
        return this.modifyDabl(param, id);
    }

    @PatchMapping(value = "/dabl/cancel/{ctcId}")
    public Dabl modifyDabl(@PathVariable String ctcId) {
        Dabl retPayment = null;
        List<Dabl> dablList = dablRepository.findBydablid(Long.parseLong(ctcId));
        

        for (Dabl dabl : dablList) {
            dabl.setStatus("CANCEL");

            retPayment = dablRepository.save(dabl);
        }

        return retPayment;
    }

    @PutMapping(value = "/dabl/cancel/{ctcId}")
    public Dabl modifyDablPut(@PathVariable String ctcId) {
        return this.modifyDabl(ctcId);
    }

    @GetMapping(value = "/dabl/{id}")
    public Dabl inquiryDablById(@PathVariable String id) {

        Optional<Dabl> opt = dablRepository.findById(Long.parseLong(id));
        Dabl payment = null;

        if (opt.isPresent())
            payment = opt.get();

        return payment;
    }

    @GetMapping(value = "/dabl")
    public Iterable<Dabl> inquiryDabl() {

        Iterable<Dabl> iter = dablRepository.findAll();

        return iter;
    }        
 }
