package ctcdabl;

import ctcdabl.config.kafka.KafkaProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{
    @Autowired DablRepository dablRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverCtcCancel_CancelDabl(@Payload CtcCancel ctcCancel){

        if(!ctcCancel.validate()) return;

        System.out.println("\n\n##### listener CancelDabl : " + ctcCancel.toJson() + "\n\n");

        // Sample Logic //
        Dabl dabl = new Dabl();
        dablRepository.save(dabl);
            
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverCtcModified_ModifyDabl(@Payload CtcModified ctcModified){

        if(!ctcModified.validate()) return;

        System.out.println("\n\n##### listener ModifyDabl : " + ctcModified.toJson() + "\n\n");

        // Sample Logic //
        Dabl dabl = new Dabl();
        dablRepository.save(dabl);
            
    }


    @StreamListener(KafkaProcessor.INPUT)
    public void whatever(@Payload String eventString){}


}
