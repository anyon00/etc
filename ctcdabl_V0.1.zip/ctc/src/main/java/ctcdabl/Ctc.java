package ctcdabl;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import ctcdabl.external.Dabl;
import ctcdabl.external.DablService;


@Entity
@Table(name="Ctc_table")
public class Ctc {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Long ctcid;
    private String customerName;
    private String memo;
    private String status;
    private String cdate;
    private Long dablid;

    @PostPersist
    public void onPostPersist() throws Exception {
        //Following code causes dependency to external APIs
        // it is NOT A GOOD PRACTICE. instead, Event-Policy mapping is recommended.

        Dabl dabl = new Dabl();
        // mappings goes here
        dabl.setDablid(this.getCtcid());
        dabl.setDablmemo(this.getMemo());
        dabl.setStatus("DABL_CREATE");


        if (CtcApplication.applicationContext.getBean(DablService.class).dabl(dabl)) {
            CtcRegistered ctcRegistered = new CtcRegistered();
            BeanUtils.copyProperties(this, ctcRegistered);
            ctcRegistered.publishAfterCommit();
        } else {
            throw new RollbackException("Failed during dabl");
        }


    }

    @PostUpdate
    public void onPostUpdate(){
        CtcModified ctcModified = new CtcModified();
        BeanUtils.copyProperties(this, ctcModified);
        ctcModified.publishAfterCommit();


    }

    @PreRemove
    public void onPreRemove(){
        CtcCancel ctcCancel = new CtcCancel();
        BeanUtils.copyProperties(this, ctcCancel);
        ctcCancel.publishAfterCommit();


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getCtcid() {
        return ctcid;
    }

    public void setCtcid(Long ctcid) {
        this.ctcid = ctcid;
    }
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String string) {
        this.customerName = string;
    }
    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public String getCdate() {
        return cdate;
    }

    public void setCdate(String cdate) {
        this.cdate = cdate;
    }
    public Long getDablid() {
        return dablid;
    }

    public void setDablid(Long dablid) {
        this.dablid = dablid;
    }




}
