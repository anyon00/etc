package ctcdabl.external;

public class Dabl {

    private Long id;
    private Long dablid;
    private String dablmemo;
    private String status;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getDablid() {
        return dablid;
    }
    public void setDablid(Long dablid) {
        this.dablid = dablid;
    }
    public String getDablmemo() {
        return dablmemo;
    }
    public void setDablmemo(String dablmemo) {
        this.dablmemo = dablmemo;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

}
