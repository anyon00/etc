package ctcdabl;

import org.springframework.data.repository.PagingAndSortingRepository;

// @RepositoryRestResource(collectionResourceRel="ctcs", path="ctcs")
public interface CtcRepository extends PagingAndSortingRepository<Ctc, Long>{


}
