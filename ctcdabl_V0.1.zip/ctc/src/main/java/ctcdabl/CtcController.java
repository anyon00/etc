package ctcdabl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


 @RestController
 public class CtcController {
     @Autowired
     CtcRepository ctcRepository;

     String eventType;
     String timestamp;
     
     public CtcController(){
        this.setEventType(this.getClass().getSimpleName());
        SimpleDateFormat defaultSimpleDateFormat = new SimpleDateFormat("YYYYMMddHHmmss");
        this.timestamp = defaultSimpleDateFormat.format(new Date());
    }

     private void setEventType(String eventType) {
        this.eventType = eventType;
    }

    @PostMapping(value = "/ctc")
     public Ctc registerCtc(@RequestBody Map<String, String> param) {
         
         Ctc cla = new Ctc();
         cla.setCtcid(Long.parseLong(param.get("ctcId")));
         cla.setCustomerName(param.get("name"));
         cla.setMemo(param.get("memo"));
         cla.setStatus("CTC_CREATE");
         cla.setCdate(this.timestamp);

         cla = ctcRepository.save(cla);

         return cla;
     }

     @PatchMapping(value = "/ctc/{id}")
     public Ctc modifyCtc(@RequestBody Map<String, String> param, @PathVariable String id) {
 
         Optional<Ctc> opt = ctcRepository.findById(Long.parseLong(id));
         Ctc cla = null;
 
         if (opt.isPresent()) {
             cla = opt.get();
 
             if (param.get("ctcId") != null)
                 cla.setCtcid(Long.parseLong(param.get("ctcId")));
             if (param.get("name") != null)
                 cla.setCustomerName(param.get("name"));
             if (param.get("memo") != null)
                 cla.setMemo(param.get("memo"));
 
             cla = ctcRepository.save(cla);
         }
          return cla;
     }
 
     @PutMapping(value = "/ctc/{id}")
     public Ctc modifyCtcPut(@RequestBody Map<String, String> param, @PathVariable String id) {
         return this.modifyCtc(param, id);
     }
 
     @GetMapping(value = "/ctc/{id}")
     public Ctc inquiryCtcById(@PathVariable String id) {
 
         Optional<Ctc> opt = ctcRepository.findById(Long.parseLong(id));
         Ctc cla = null;
 
         if (opt.isPresent())
             cla = opt.get();
 
         return cla;
     }
 
     @GetMapping(value = "/ctc")
     public Iterable<Ctc> inquiryClass() {
 
         Iterable<Ctc> iter = ctcRepository.findAll();
 
         return iter;
     }
 
     @DeleteMapping(value = "/ctc/{id}")
     public boolean deleteClass(@PathVariable String id) {
         boolean result = false;
 
         ctcRepository.deleteById(Long.parseLong(id));
         result = true;
 
         return result;
     }


 }
