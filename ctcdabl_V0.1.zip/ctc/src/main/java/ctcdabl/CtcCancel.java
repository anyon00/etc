
package ctcdabl;

public class CtcCancel extends AbstractEvent {

    private Long id;
    private Long ctcid;
    private String customerName;
    private String memo;
    private String status;
    private String cdate;
    private Long dablid;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getCtcid() {
        return ctcid;
    }

    public void setCtcid(Long ctcid) {
        this.ctcid = ctcid;
    }
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public String getCdate() {
        return cdate;
    }

    public void setCdate(String cdate) {
        this.cdate = cdate;
    }
    public Long getDablid() {
        return dablid;
    }

    public void setDablid(Long dablid) {
        this.dablid = dablid;
    }
}

