
import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router);


import DablManager from "./components/DablManager"

import CtcManager from "./components/CtcManager"

export default new Router({
    // mode: 'history',
    base: process.env.BASE_URL,
    routes: [
            {
                path: '/Dabl',
                name: 'DablManager',
                component: DablManager
            },

            {
                path: '/Ctc',
                name: 'CtcManager',
                component: CtcManager
            },



    ]
})
